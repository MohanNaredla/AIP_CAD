// import React, { useEffect, useState } from "react";
// import { Student } from "@/types";
// import { Button } from "@/components/ui/button";
// import {
//   DropdownMenu,
//   DropdownMenuContent,
//   DropdownMenuItem,
//   DropdownMenuTrigger,
// } from "@/components/ui/dropdown-menu";

// interface Props {
//   students: Student[];
//   selectedStudent: Student;
//   onSelect: (s: Student) => void;
// }

// export const StudentSelector: React.FC<Props> = ({
//   students,
//   selectedStudent,
//   onSelect,
// }) => {
//   const gradeOrder = [
//     "Pre-Kindergarten",
//     "Kindergarten",
//     "1st Grade",
//     "2nd Grade",
//     "3rd Grade",
//     "4th Grade",
//     "5th Grade",
//     "6th Grade",
//     "7th Grade",
//     "8th Grade",
//     "9th Grade",
//     "10th Grade",
//     "11th Grade",
//     "12th Grade",
//   ];

//   const [selectedSchool, setSelectedSchool] = useState<string | null>(null);
//   const [selectedGrade, setSelectedGrade] = useState<string | null>(null);
//   const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null);

//   // Filter students by Location ID
//   const filteredByLocation = selectedSchool
//     ? students.filter((s) => s.schoolName === selectedSchool)
//     : students;

//   // Get unique Location IDs for the dropdown
//   const locationIds = Array.from(new Set(students.map((s) => s.schoolName)));

//   // Get unique grades available for the selected Location ID
//   const availableGrades = Array.from(
//     new Set(filteredByLocation.map((s) => s.grade))
//   );

//   // Filter students further by Grade
//   const filteredStudents = selectedGrade
//     ? filteredByLocation
//         .filter((s) => s.grade === selectedGrade)
//         .sort((a, b) => {
//           // Sort by Location_ID first
//           if (a.schoolName !== b.schoolName) {
//             return a.schoolName.localeCompare(b.schoolName);
//           }
//           // Sort by Grade
//           const gradeAIndex = gradeOrder.indexOf(a.grade);
//           const gradeBIndex = gradeOrder.indexOf(b.grade);
//           if (gradeAIndex !== gradeBIndex) {
//             return gradeAIndex - gradeBIndex;
//           }
//           // Sort by Student ID last
//           return a.id.localeCompare(b.id);
//         })
//     : filteredByLocation;

//   useEffect(() => {
//     console.log("Filtered students:", filteredStudents);
//   }, [filteredStudents]);

//   return (
//     <div className="flex gap-4 mb-6">
//       <div>
//         <p className="text-sm font-semibold mb-1">Select School</p>
//         <DropdownMenu>
//           <DropdownMenuTrigger asChild>
//             <Button variant="outline" size="sm">
//               {selectedSchool || "Choose School"}
//             </Button>
//           </DropdownMenuTrigger>
//           <DropdownMenuContent className="max-h-60 overflow-y-auto w-52">
//             {locationIds.map((location) => (
//               <DropdownMenuItem
//                 key={location}
//                 onClick={() => {
//                   console.log("Selected location:", location);
//                   setSelectedSchool(location);
//                   setSelectedGrade(null); // Reset grade when location changes
//                 }}
//               >
//                 {location}
//               </DropdownMenuItem>
//             ))}
//           </DropdownMenuContent>
//         </DropdownMenu>
//       </div>

//       {/* Grade Dropdown */}
//       <div>
//         <p className="text-sm font-semibold mb-1">Select Grade</p>
//         <DropdownMenu>
//           <DropdownMenuTrigger asChild>
//             <Button variant="outline" size="sm" disabled={!selectedSchool}>
//               {selectedGrade || "Choose Grade"}
//             </Button>
//           </DropdownMenuTrigger>
//           <DropdownMenuContent className="max-h-60 overflow-y-auto w-52">
//             {availableGrades.length === 0 ? (
//               <DropdownMenuItem disabled>No grades available</DropdownMenuItem>
//             ) : (
//               availableGrades.map((grade) => (
//                 <DropdownMenuItem
//                   key={grade}
//                   onClick={() => {
//                     console.log("Selected grade:", grade);
//                     setSelectedGrade(grade);
//                   }}
//                 >
//                   {grade}
//                 </DropdownMenuItem>
//               ))
//             )}
//           </DropdownMenuContent>
//         </DropdownMenu>
//       </div>

//       {/* Student Dropdown */}
//       <div>
//         <p className="text-sm font-semibold mb-1">Select Student</p>
//         <DropdownMenu>
//           <DropdownMenuTrigger asChild>
//             <Button
//               variant="outline"
//               size="sm"
//               disabled={!selectedGrade || filteredStudents.length === 0}
//             >
//               {selectedStudent?.id || "Choose Student"}
//             </Button>
//           </DropdownMenuTrigger>
//           <DropdownMenuContent className="max-h-60 overflow-y-auto w-52">
//             {filteredStudents.length === 0 ? (
//               <DropdownMenuItem disabled>No students</DropdownMenuItem>
//             ) : (
//               filteredStudents.map((s) => (
//                 <DropdownMenuItem
//                   key={s.id}
//                   onClick={() => {
//                     console.log("Selected student:", s);
//                     onSelect(s);
//                   }}
//                   className="flex justify-between"
//                 >
//                   <span>{s.id}</span>
//                   <span className="text-xs text-muted-foreground">
//                     {s.grade}
//                   </span>
//                 </DropdownMenuItem>
//               ))
//             )}
//           </DropdownMenuContent>
//         </DropdownMenu>
//       </div>
//     </div>
//   );
// };



import React, { useEffect, useState } from "react";
import { Student } from "@/types";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Props {
  students: Student[];
  selectedStudent: Student;
  onSelect: (s: Student) => void;
}

export const StudentSelector: React.FC<Props> = ({
  students,
  selectedStudent,
  onSelect,
}) => {
  const gradeOrder = [
    "Pre-Kindergarten",
    "Kindergarten",
    "1st Grade",
    "2nd Grade",
    "3rd Grade",
    "4th Grade",
    "5th Grade",
    "6th Grade",
    "7th Grade",
    "8th Grade",
    "9th Grade",
    "10th Grade",
    "11th Grade",
    "12th Grade",
  ];

  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null);
  const [selectedSchool, setSelectedSchool] = useState<string | null>(null);
  const [selectedGrade, setSelectedGrade] = useState<string | null>(null);

  // Filter students by District Name
  const filteredByDistrict = selectedDistrict
    ? students.filter((s) => s.districtName === selectedDistrict)
    : students;

  // Get unique District Names for the dropdown
  const districtNames = Array.from(new Set(students.map((s) => s.districtName)));

  // Filter students by Location ID (School)
  const filteredByLocation = selectedSchool
    ? filteredByDistrict.filter((s) => s.schoolName === selectedSchool)
    : filteredByDistrict;

  // Get unique Location IDs for the dropdown
  const locationIds = Array.from(new Set(filteredByDistrict.map((s) => s.schoolName)));

  // Get unique grades available for the selected Location ID
  const availableGrades = Array.from(
    new Set(filteredByLocation.map((s) => s.grade))
  );

  // Filter students further by Grade
  const filteredStudents = selectedGrade
    ? filteredByLocation
        .filter((s) => s.grade === selectedGrade)
        .sort((a, b) => {
          // Sort by Location_ID first
          if (a.schoolName !== b.schoolName) {
            return a.schoolName.localeCompare(b.schoolName);
          }
          // Sort by Grade
          const gradeAIndex = gradeOrder.indexOf(a.grade);
          const gradeBIndex = gradeOrder.indexOf(b.grade);
          if (gradeAIndex !== gradeBIndex) {
            return gradeAIndex - gradeBIndex;
          }
          // Sort by Student ID last
          return a.id.localeCompare(b.id);
        })
    : filteredByLocation;

  useEffect(() => {
    console.log("Filtered students:", filteredStudents);
  }, [filteredStudents]);

  return (
    <div className="flex gap-4 mb-6">
      {/* District Dropdown */}
      <div>
        <p className="text-sm font-semibold mb-1">Select District</p>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              {selectedDistrict || "Choose District"}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="max-h-60 overflow-y-auto w-52">
            {districtNames.map((district) => (
              <DropdownMenuItem
                key={district}
                onClick={() => {
                  console.log("Selected district:", district);
                  setSelectedDistrict(district);
                  setSelectedSchool(null); // Reset school when district changes
                  setSelectedGrade(null); // Reset grade when district changes
                }}
              >
                {district}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* School Dropdown */}
      <div>
        <p className="text-sm font-semibold mb-1">Select School</p>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" disabled={!selectedDistrict}>
              {selectedSchool || "Choose School"}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="max-h-60 overflow-y-auto w-52">
            {locationIds.length === 0 ? (
              <DropdownMenuItem disabled>No schools available</DropdownMenuItem>
            ) : (
              locationIds.map((location) => (
                <DropdownMenuItem
                  key={location}
                  onClick={() => {
                    console.log("Selected location:", location);
                    setSelectedSchool(location);
                    setSelectedGrade(null); // Reset grade when location changes
                  }}
                >
                  {location}
                </DropdownMenuItem>
              ))
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Grade Dropdown */}
      <div>
        <p className="text-sm font-semibold mb-1">Select Grade</p>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" disabled={!selectedSchool}>
              {selectedGrade || "Choose Grade"}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="max-h-60 overflow-y-auto w-52">
            {availableGrades.length === 0 ? (
              <DropdownMenuItem disabled>No grades available</DropdownMenuItem>
            ) : (
              availableGrades.map((grade) => (
                <DropdownMenuItem
                  key={grade}
                  onClick={() => {
                    console.log("Selected grade:", grade);
                    setSelectedGrade(grade);
                  }}
                >
                  {grade}
                </DropdownMenuItem>
              ))
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Student Dropdown */}
      <div>
        <p className="text-sm font-semibold mb-1">Select Student</p>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              disabled={!selectedGrade || filteredStudents.length === 0}
            >
              {selectedStudent?.id || "Choose Student"}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="max-h-60 overflow-y-auto w-52">
            {filteredStudents.length === 0 ? (
              <DropdownMenuItem disabled>No students</DropdownMenuItem>
            ) : (
              filteredStudents.map((s) => (
                <DropdownMenuItem
                  key={s.id}
                  onClick={() => {
                    console.log("Selected student:", s);
                    onSelect(s);
                  }}
                  className="flex justify-between"
                >
                  <span>{s.id}</span>
                  <span className="text-xs text-muted-foreground">
                    {s.grade}
                  </span>
                </DropdownMenuItem>
              ))
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};
