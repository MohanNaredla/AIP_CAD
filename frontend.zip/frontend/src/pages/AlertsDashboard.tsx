import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Download } from "lucide-react";

const AlertsDashboard: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50/50">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <h1 className="text-3xl font-bold mb-1">Alerts Dashboard</h1>
        <p className="text-muted-foreground mb-8">
          Monitor alerts and notifications
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm text-muted-foreground">
                Alert Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Replace with alert components later */}
              <div className="text-sm text-gray-500">No alerts to show yet.</div>
            </CardContent>
          </Card>
        </div>
      </div>
      <div className="mt-8 flex justify-center">
      <a
  href="http://127.0.0.1:8001/download/csv"
  className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded hover:bg-blue-700 transition-colors"
>
  <Download className="w-4 h-4 mr-2" />
  Download Chronic Attendace CSV
</a>
</div>  
    </div>
  );
};

export default AlertsDashboard;
